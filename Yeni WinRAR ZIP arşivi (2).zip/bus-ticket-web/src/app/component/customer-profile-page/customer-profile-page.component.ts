import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-profile-page',
  templateUrl: './customer-profile-page.component.html',
  styleUrl: './customer-profile-page.component.css',
})
export class CustomerProfilePageComponent {
  currentPage: string = 'ticket';

  information() {
    this.currentPage = 'information';
  }

  ticket() {
    this.currentPage = 'ticket';
  }

  delete() {
    this.currentPage = 'delete';
  }
  change() {
    this.currentPage = 'change';
  }
}
