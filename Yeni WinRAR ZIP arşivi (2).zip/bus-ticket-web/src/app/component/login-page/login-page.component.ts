import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
})
export class LoginPageComponent {
  email: string = '';
  password: string = '';

  constructor(private router: Router) {}

  login() {
    if (this.email.trim() === '' || this.password.trim() === '') {
      alert('Please fill in both email and password fields.');
    } else {
      // Proceed with login
      this.router.navigate(['/anasayfa']); // Change '/anasayfa' to your desired route
    }
  }
}
