import { Component, OnInit } from '@angular/core';
declare let alertify: any;

@Component({
  selector: 'app-pay-page',
  templateUrl: './pay-page.component.html',
  styleUrl: './pay-page.component.css',
})
export class PayPageComponent implements OnInit {
  name: string = '';
  surname: string = '';
  mail: string = '';
  address: string = '';
  phoneNumber: string = '';
  city: string = '';
  zipCode: string = '';
  nameOnCard: string = '';
  cardNumber: string = '';
  expMonth: string = '';
  expYear: string = '';
  cvv: string = '';
  accept: boolean = false;
  country: string = '';
  payMethod: string = '';

  years: number[] = [];

  constructor() {}

  ngOnInit(): void {
    const startYear = 2024;

    for (let i = 0; i < 10; i++) {
      this.years.push(startYear + i);
    }
  }

  payTicket() {
    if (
      this.name.trim() === '' ||
      this.surname.trim() === '' ||
      this.mail.trim() === '' ||
      this.address.trim() === '' ||
      this.phoneNumber.trim() === '' ||
      this.city.trim() === '' ||
      this.zipCode.trim() === '' ||
      this.nameOnCard.trim() === '' ||
      this.cardNumber.trim() === '' ||
      this.expMonth.trim() === '' ||
      this.expYear.trim() === '' ||
      this.cvv.trim() === '' ||
      !this.accept ||
      this.country.trim() === '' ||
      this.payMethod.trim() === ''
    ) {
      alertify.error('Please fill in all fields..');
    } else {
      alertify.success('Payment is success');
    }
  }
}
