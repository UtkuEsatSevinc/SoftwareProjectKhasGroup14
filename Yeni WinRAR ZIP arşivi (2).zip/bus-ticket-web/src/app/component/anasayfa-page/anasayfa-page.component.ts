import { Component } from '@angular/core';

@Component({
  selector: 'app-anasayfa-page',
  templateUrl: './anasayfa-page.component.html',
  styleUrl: './anasayfa-page.component.css'
})
export class AnasayfaPageComponent {

}
