import { Component, OnInit } from '@angular/core';
import { Bilet } from './bilet';
import { BiletService } from '../../../bilet-service/bilet.service';
import { FormBuilder, FormGroup } from '@angular/forms';
declare let alertify: any;

@Component({
  selector: 'app-ticket',
  templateUrl: './ticket.component.html',
  styleUrl: './ticket.component.css',
})
export class TicketComponent implements OnInit {
  currentGun = 0;
  selectedKalkisYeri?: string;
  seferFilterForm!: FormGroup;
  seferFilters?: { kalkisYeri: string; varisYeri: string; seferSaat: string };

  birinciGun() {
    this.currentGun = 0;
  }

  ikinciGun() {
    this.currentGun = 1;
  }

  ucuncuGun() {
    this.currentGun = 2;
  }

  dorduncuGun() {
    this.currentGun = 3;
  }

  besinciGun() {
    this.currentGun = 4;
  }

  altinciGun() {
    this.currentGun = 5;
  }

  yedinciGun() {
    this.currentGun = 6;
  }

  biletler: Bilet[][] = [];

  kalkisYerleri: string[] = [];
  varisYerleri: string[] = [];

  constructor(
    private biletService: BiletService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.getBiletler();
    this.seferFilterForm = this.formBuilder.group({
      kalkisYeri: [''], // Set default value or leave it empty
      varisYeri: [''], // Set default value or leave it empty
      seferSaat: [''], // Set default value or leave it empty
    });
  }

  getBiletler(): void {
    this.biletler = this.biletService.getSeferler();
    this.biletler.forEach((biletGun) => {
      biletGun.forEach((bilet) => {
        this.kalkisYerleri.push(bilet.kalkis);
        this.varisYerleri.push(bilet.varis);
      });
    });

    // Remove duplicate elements
    this.kalkisYerleri = [...new Set(this.kalkisYerleri)];
    this.varisYerleri = [...new Set(this.varisYerleri)];
  }

  onFormSubmit() {
    if (this.seferFilterForm.valid) {
      const formValues = this.seferFilterForm.value;
      this.seferFilters = formValues;
    } else {
      alertify.error('The requested travel is not available');
    }
  }

  title = 'Search Ticket';
  title1 = 'Ticket List';
  title2 = 'Ticket Detail';
  filterText = '';
  showDetails: boolean = false;

  addToCart() {
    alertify.success('Bilet Satın İşlemleriniz Başladı');
  }

  selectedBilet: any;

  toggleDetails(bilet: any) {
    this.selectedBilet = bilet;
    this.showDetails = true;
  }
}
