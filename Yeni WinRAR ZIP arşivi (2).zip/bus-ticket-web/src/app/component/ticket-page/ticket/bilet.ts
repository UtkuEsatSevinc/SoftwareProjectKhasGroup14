export class Bilet {
  id: number = 0;
  name: string = '';
  price: number = 0;
  description: string = '';
  image: string = '';
  kalkis: string = '';
  varis: string = '';
  kalkisSaat: string = '';
  seferSaat: string = '';
}
