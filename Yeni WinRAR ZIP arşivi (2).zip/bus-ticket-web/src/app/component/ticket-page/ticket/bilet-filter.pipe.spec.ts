import { BiletFilterPipe } from './bilet-filter.pipe';

describe('BiletFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new BiletFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
