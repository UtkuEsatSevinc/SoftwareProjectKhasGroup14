export interface SignupForm {
  name: string;
  surname: string;
  email: string;
  password: string;
  phoneNumber: string;
  turkishCitizenshipNumber: string;
  gender: string;
}
