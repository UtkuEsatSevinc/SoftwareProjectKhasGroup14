import { Component } from '@angular/core';
import { SignupForm } from './sign-up';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up-page',
  templateUrl: './sign-up-page.component.html',
  styleUrl: './sign-up-page.component.css',
})
export class SignUpPageComponent {
  formData: SignupForm = {
    name: '',
    surname: '',
    email: '',
    password: '',
    phoneNumber: '',
    turkishCitizenshipNumber: '',
    gender: '',
  };

  constructor(private router: Router) {}

  signUp() {
    if (
      this.formData.name.trim() === '' ||
      this.formData.surname.trim() === '' ||
      this.formData.email.trim() === '' ||
      this.formData.password.trim() === '' ||
      this.formData.phoneNumber.trim() === '' ||
      this.formData.turkishCitizenshipNumber.trim() === '' ||
      this.formData.gender.trim() === ''
    ) {
      alert('Please fill in all fields.');
    } else {
      this.router.navigate(['/anasayfa']);
    }
  }
}
