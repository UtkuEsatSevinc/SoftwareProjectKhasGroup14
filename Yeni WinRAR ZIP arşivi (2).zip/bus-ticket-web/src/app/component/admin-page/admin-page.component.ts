import { Component, OnInit } from '@angular/core';
declare let alertify: any;

interface Driver {
  tcno: number;
  name: string;
  licenseNumber: string;
}

interface Travel {
  id: number;
  from: string;
  to: string;
  date: string;
  driverTcno?: number;
}

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrl: './admin-page.component.css',
})
export class AdminPageComponent implements OnInit {
  currentPage: string = 'addTravel';
  addDriver() {
    this.currentPage = 'addDriver';
  }

  addTravel() {
    this.currentPage = 'addTravel';
  }

  dropDriver() {
    this.currentPage = 'dropDriver';
  }

  dropTravel() {
    this.currentPage = 'dropTravel';
  }

  driverTravel() {
    this.currentPage = 'driverTravel';
  }

  ngOnInit(): void {
    const form = document.getElementById('dateForm') as HTMLFormElement;
    const datetimeInput = document.getElementById(
      'datetime'
    ) as HTMLInputElement;
    const messageParagraph = document.getElementById(
      'message'
    ) as HTMLParagraphElement;

    form.onsubmit = (event) => {
      event.preventDefault();

      const userInput = new Date(datetimeInput.value);
      const minimumDate = new Date('2024-05-07T00:00');

      if (userInput < minimumDate) {
        messageParagraph.textContent =
          'Girilen tarih 2024-07-05 tarihinden önce olamaz.';
      } else {
        messageParagraph.textContent = 'Girilen tarih geçerli.';
        // Formu sunucuya göndermek için burada bir işlem yapılabilir.
        // form.submit(); // Sunucuya göndermek için yorumu kaldırın.
      }
    };
  }

  addCity(): void {
    const newCityInput = document.getElementById('newCity') as HTMLInputElement;
    const newCityName = newCityInput.value.trim();

    if (newCityName) {
      const departureSelect = document.getElementById(
        'departureCity'
      ) as HTMLSelectElement;
      const arrivalSelect = document.getElementById(
        'arrivalCity'
      ) as HTMLSelectElement;

      // Kalkış şehirlerine yeni şehir eklemek
      let newOption = new Option(newCityName, newCityName);
      departureSelect.options.add(newOption);

      // Varış şehirlerine yeni şehir eklemek
      newOption = new Option(newCityName, newCityName);
      arrivalSelect.options.add(newOption);

      // Ekleme yapıldıktan sonra input alanını temizle
      newCityInput.value = '';
    } else {
      alert('Lütfen geçerli bir şehir adı giriniz.');
    }
  }

  selectedDriverTcno!: number;

  assignDriver(travelId: number): void {
    const travel = this.travels.find((travel) => travel.id === travelId);
    if (travel) {
      travel.driverTcno = this.selectedDriverTcno;
    }
  }

  getDriverName(tcno: number | undefined): string | undefined {
    return this.drivers.find((driver) => driver.tcno === tcno)?.name;
  }

  eslesme() {
    alertify.success('İşlem Tamamlandı');
  }

  travels: Travel[] = [
    { id: 1, from: 'Karabük', to: 'İzmir', date: '2024-05-21 Time: 14:30' },
    { id: 2, from: 'İstanbul', to: 'Bursa', date: '2024-05-22 Time: 10:15' },
    { id: 3, from: 'Antalya', to: 'Konya', date: '2024-05-23 Time: 23:50' },
  ];

  onDeleteTravel(id: number): void {
    this.travels = this.travels.filter((travel) => travel.id !== id);
  }

  drivers: Driver[] = [
    { tcno: 12345678901, name: 'Ahmet Yılmaz', licenseNumber: 'ABC123' },
    { tcno: 23456789012, name: 'Mehmet Özcan', licenseNumber: 'XYZ789' },
    { tcno: 34567890123, name: 'Elif Toprak', licenseNumber: 'DEF456' },
  ];

  onDeleteDriver(tcno: number): void {
    this.drivers = this.drivers.filter((driver) => driver.tcno !== tcno);
  }
}
